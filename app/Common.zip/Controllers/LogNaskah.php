<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class LogNaskah extends BaseController
{
    public function index()
    {
        //
    }
}
