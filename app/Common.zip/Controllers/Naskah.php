<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\IndeksModel;
use App\Models\JenisModel;
use App\Models\KlasifikasiModel;
use App\Models\NaskahKeluarModel;
use App\Models\NaskahMasukModel;
use App\Models\NaskahModel;
use App\Models\PegawaiModel;
use App\Models\SifatModel;
use App\Models\UrgensiModel;
use CodeIgniter\I18n\Time;

class Naskah extends BaseController
{
    public function __construct()
    {
        $this->session = session();
        $this->NaskahModel = new NaskahModel();
        $this->NaskahMasukModel = new NaskahMasukModel();
        $this->NaskahKeluarModel = new NaskahKeluarModel();
        $this->PegawaiModel = new PegawaiModel();
        $this->JenisModel = new JenisModel();
        $this->SifatModel = new SifatModel();
        $this->UrgensiModel = new UrgensiModel();
        $this->KlasifikasiModel = new KlasifikasiModel();
        $this->IndeksModel = new IndeksModel();
    }

    public function index()
    {
        //
    }

    // show form registrasi naskah masuk 
    public function reg_masuk()
    {

        $pegawai    = $this->PegawaiModel->getData();
        $jenis      = $this->JenisModel->getData()->getResultArray();
        $sifat      = $this->SifatModel->getData()->getResultArray();
        $urgensi      = $this->UrgensiModel->getData()->getResultArray();

        $data['pegawai'] = $pegawai;
        $data['jenis'] = $jenis;
        $data['sifat'] = $sifat;
        $data['urgensi'] = $urgensi;

        // load views
        echo view("layout/header");
        echo view("layout/navbar");
        echo view("layout/sidebar");
        echo view("req_naskah_masuk", $data);
        echo view("layout/footer");
    }

    // show form registrasi naskah keluar
    public function reg_keluar()
    {

        $pegawai    = $this->PegawaiModel->getData();
        $jenis      = $this->JenisModel->getData()->getResultArray();
        $sifat      = $this->SifatModel->getData()->getResultArray();
        $urgensi      = $this->UrgensiModel->getData()->getResultArray();
        $klasifikasi = $this->KlasifikasiModel->getData()->getResultArray();
        $indeks = $this->IndeksModel->getData()->getResultArray();

        $data['pegawai'] = $pegawai;
        $data['jenis'] = $jenis;
        $data['sifat'] = $sifat;
        $data['urgensi'] = $urgensi;
        $data['klasifikasi'] = $klasifikasi;
        $data['indeks'] = $indeks;

        // load views
        echo view("layout/header");
        echo view("layout/navbar");
        echo view("layout/sidebar");
        echo view("req_naskah_keluar", $data);
        echo view("layout/footer");
    }

    // submit naskah masuk 
    public function submit_masuk()
    {
        // get dari input user 
        $pengirim    = $this->request->getPost('nama_pengirim');
        $jabatan     = $this->request->getPost('jabatan_pengirim');
        $instansi    = $this->request->getPost('instansi_pengirim');
        $jenis       = $this->request->getPost('jenis_naskah_id');
        $sifat       = $this->request->getPost('sifat_naskah_id');
        $urgensi       = $this->request->getPost('urgensi_naskah_id');
        $nomor       = $this->request->getPost('nomor');
        $referensi  = $this->request->getPost('reply_id');
        $tgl_naskah = $this->request->getPost('date');
        $tgl_diterima = $this->request->getPost('received_at');
        $hal = $this->request->getPost('hal');
        $ringkasan = $this->request->getPost('ringkasan');
        $tujuan = $this->request->getPost('tujuan_id');
        $tembusan = $this->request->getPost('tembusan_id');
        $file_naskah = $this->request->getFile('file_naskah');
        $lampiran = $this->request->getFile('lampiran');

        // validation     
        if ($lampiran == "") {
            $file_naskah_name = "";
            $lampiran_name = "";
            $status_berkas = "Tidak ada lampiran";
        } else {
            $file_naskah_name = $file_naskah->getName();
            $lampiran_name = $lampiran->getName();
            $status_berkas = "Naskah dan Lampiran Lengkap";
            // pindahkan berkas ke directory lain 
            $file_naskah->move('uploads/surat_masuk/naskah', $file_naskah_name);
            $lampiran->move('uploads/surat_masuk/lampiran', $lampiran_name);
        }
        
        $data = [
            'pengirim'  => $pengirim,
            'jabatan'   => $jabatan,
            'instansi'  => $instansi,
            'jenis'     => $jenis,
            'sifat'     => $sifat,
            'urgensi'   => $urgensi,
            'nomor_naskah'      => $nomor,
            'nomor_referensi'   => $referensi,
            'tgl_naskah'        => $tgl_naskah,
            'tgl_diterima'      => $tgl_diterima,
            'hal'       => $hal,
            'ringkasan' => $ringkasan,
            'tujuan'    => $tujuan,
            'tembusan'  => $tembusan,
            'path_naskah'       => $file_naskah_name,
            'path_lampiran'     => $lampiran_name,
            'status_berkas'     => $status_berkas
        ];

        if ($this->NaskahModel->insertNaskahMasuk($data) == true) { //jika berhasil menambahkan data
            $datalog = [
                'username'      => $this->session->username,
                'nama'          => $this->session->nama,
                'created_at'    => Time::now('Asia/Singapore','en_US'),
                'nomor_naskah'  => $nomor,
                'aksi'          => 'Menambah Surat Masuk'
            ];
            
            $this->NaskahModel->insertLog($datalog);
            $this->session->setFlashdata('pesan_add', 'Berhasil Menambahkan Data');
            $this->session->setFlashdata('alert-class', 'alert-success');
        } else {
            $this->session->setFlashdata('pesan_add', 'Gagal Menambahkan Data');
            $this->session->setFlashdata('alert-class', 'alert-danger');
        }

        return redirect()->to('/naskah-masuk');
    }

    public function submit_keluar()
    {
        // get from user input 
        $pengirim = $this->request->getPost('sender_user_id');
        $tanggal = $this->request->getPost('date');
        $jenis       = $this->request->getPost('jenis_naskah_id');
        $sifat       = $this->request->getPost('sifat_naskah_id');
        $urgensi     = $this->request->getPost('urgensi_naskah_id');
        $nomor       = $this->request->getPost('nomor');
        $referensi  = $this->request->getPost('reply_id');
        $hal = $this->request->getPost('hal');
        $ringkasan = $this->request->getPost('ringkasan');
        $file_naskah = $this->request->getFile('file_naskah');
        $lampiran = $this->request->getFile('lampiran');
        $tujuan_internal = $this->request->getPost('tujuan_internal_id');
        $tembusan_internal = $this->request->getPost('tembusan_internal_id');
        $tujuan_eksternal = $this->request->getPost('tujuan_eksternal_id');
        $tembusan_eksternal = $this->request->getPost('tembusan_eksternal_id');
        $verifikator = $this->request->getPost('verifikator');
        $penandatangan = $this->request->getPost('penandatangan');
        $ttd = $this->request->getPost('ttd');


        if ($lampiran == "") {
            $file_naskah_name = "";
            $lampiran_name = "";
        } else {
            $file_naskah_name = $file_naskah->getName();
            $lampiran_name = $lampiran->getName();

            // pindahkan berkas ke directory lain 
            $file_naskah->move('uploads/surat_keluar/naskah', $file_naskah_name);
            $lampiran->move('uploads/surat_keluar/lampiran', $lampiran_name);
        }
        

        $data = [
            'unit_kerja'  => $pengirim,
            'tgl_naskah'   => $tanggal,
            'jenis'     => $jenis,
            'sifat'     => $sifat,
            'urgensi'   => $urgensi,
            'nomor_naskah'      => $nomor,
            'nomor_referensi'   => $referensi,
            'hal'       => $hal,
            'ringkasan' => $ringkasan,
            'tujuan_internal'    => $tujuan_internal,
            'tujuan_eksternal'    => $tujuan_eksternal,
            'tembusan_internal'  => $tembusan_internal,
            'tembusan_eksternal'  => $tembusan_eksternal,
            'path_naskah'       => $file_naskah_name,
            'path_lampiran'     => $lampiran_name,
            'verifikator'       => $verifikator,
            'penandatangan'     => $penandatangan,
            'ttd'               => $ttd
        ];

        if ($this->NaskahModel->insertNaskahKeluar($data) == true) {
            $datalog = [
                'username'      => $this->session->username,
                'nama'          => $this->session->nama,
                'created_at'    => Time::now('Asia/Singapore','en_US'),
                'nomor_naskah'  => $nomor,
                'aksi'          => 'Menambah Surat Keluar'
            ];
            
            $this->NaskahModel->insertLog($datalog);
            $this->session->setFlashdata('pesan_add', 'Berhasil Menambahkan Data');
            $this->session->setFlashdata('alert-class', 'alert-success');
        } else {
            $this->session->setFlashdata('pesan_add', 'Gagal Menambahkan Data');
            $this->session->setFlashdata('alert-class', 'alert-danger');
        }

        return redirect()->to('/naskah-keluar');

    }

    // show tabel daftar naskah masuk 
    public function naskah_masuk()
    {

        $naskah = $this->NaskahModel->getDataMasuk();
        $naskah = $naskah->getResultArray();
        $data['naskah'] = $naskah;

        // load views
        echo view("layout/header");
        echo view("layout/navbar");
        echo view("layout/sidebar");
        echo view("daftar_naskah_masuk", $data);
        echo view("layout/footer");
    }

    // show tabel daftar naskah keluar
    public function naskah_keluar()
    {
        $naskah = $this->NaskahModel->getDataKeluar();
        $naskah = $naskah->getResultArray();
        $data['naskah'] = $naskah;

        // load views
        echo view("layout/header");
        echo view("layout/navbar");
        echo view("layout/sidebar");
        echo view("daftar_naskah_keluar", $data);
        echo view("layout/footer");
    }

    // show daftar log input naskah masuk 
    public function log_naskah_masuk() {
        $logmasuk = $this->NaskahModel->getLogMasuk();
        $logmasuk = $logmasuk->getResultArray();
        $data['logmasuk'] = $logmasuk;

        // load views
        echo view("layout/header");
        echo view("layout/navbar");
        echo view("layout/sidebar");
        echo view("daftar_log_masuk", $data);
        echo view("layout/footer");
    }

    // show daftar log input naskah keluar
    public function log_naskah_keluar() {
        $logkeluar = $this->NaskahModel->getLogKeluar();
        $logkeluar = $logkeluar->getResultArray();
        $data['logkeluar'] = $logkeluar;

        // load views
        echo view("layout/header");
        echo view("layout/navbar");
        echo view("layout/sidebar");
        echo view("daftar_log_keluar", $data);
        echo view("layout/footer");
    }

    // // function lihat berkas naskah masuk 
    // public function lihat_naskah() {
        
    // }

    // function download berkas naskah masuk 
    public function download_naskah_masuk() {
        $idget = $this->request->getGet();
        $naskah = $this->NaskahModel->downloadNaskahMasuk($idget);
        $naskah = $naskah->getRowArray();
        if (isset($naskah)) { 
            if ($naskah['path_naskah'] == "") { //jika path naskah surat tidk ditemukan 
                $this->session->setFlashdata('pesan_find', 'Naskah tidak ditemukan!');
                $this->session->setFlashdata('alert-class', 'alert-danger');
                return redirect()->to('/naskah-masuk');
            } else {
                return $this->response->download('uploads/surat_masuk/naskah/' . $naskah['path_naskah'], null);
            }
        } else {
            return redirect()->to('/naskah-masuk');
        }
        
    }

    // function download berkas lampiran masuk
    public function download_lampiran_masuk() {
        $idget = $this->request->getGet();
        $naskah = $this->NaskahModel->downloadNaskahMasuk($idget);
        $naskah = $naskah->getRowArray();
        if (isset($naskah)) { 
            if ($naskah['path_lampiran'] == "") { //jika path naskah surat tidk ditemukan 
                $this->session->setFlashdata('pesan_find', 'Lampiran tidak ditemukan!');
                $this->session->setFlashdata('alert-class', 'alert-danger');
                return redirect()->to('/naskah-masuk');
            } else {
                return $this->response->download('uploads/surat_masuk/lampiran/' . $naskah['path_lampiran'], null);
            }
        } else {
            return redirect()->to('/naskah-masuk');
        }
        
    }

    // function download berkas naskah keluar
    public function download_naskah_keluar() {
        $idget = $this->request->getGet();
        $naskah = $this->NaskahModel->downloadNaskahKeluar($idget);
        $naskah = $naskah->getRowArray();
        if (isset($naskah)) { 
            if ($naskah['path_naskah'] == "") { //jika path naskah surat tidk ditemukan 
                $this->session->setFlashdata('pesan_find', 'Naskah tidak ditemukan!');
                $this->session->setFlashdata('alert-class', 'alert-danger');
                return redirect()->to('/naskah-keluar');
            } else {
                return $this->response->download('uploads/surat_keluar/naskah/' . $naskah['path_naskah'], null);
            }
        } else {
            return redirect()->to('/naskah-keluar');
        }
        
    }

    // function download lampiran naskah keluar
    public function download_lampiran_keluar() {
        $idget = $this->request->getGet();
        $naskah = $this->NaskahModel->downloadNaskahKeluar($idget);
        $naskah = $naskah->getRowArray();
        if (isset($naskah)) { 
            if ($naskah['path_lampiran'] == "") { //jika path naskah surat tidk ditemukan 
                $this->session->setFlashdata('pesan_find', 'Lampiran tidak ditemukan!');
                $this->session->setFlashdata('alert-class', 'alert-danger');
                return redirect()->to('/naskah-keluar');
            } else {
                return $this->response->download('uploads/surat_keluar/lampiran/' . $naskah['path_lampiran'], null);
            }
        } else {
            return redirect()->to('/naskah-keluar');
        }
        
    }

    // show daftar template
    public function template() {
        $templates = $this->NaskahModel->getTemplates();
        $templates = $templates->getResultArray();
        $data['templates'] = $templates;

        // load views
        echo view("layout/header");
        echo view("layout/navbar");
        echo view("layout/sidebar");
        echo view("daftar_templates", $data);
        echo view("layout/footer");
    }

    // function download template
    public function download_templates() {
        $idget = $this->request->getGet();
        $template = $this->NaskahModel->downloadTemplates($idget);
        $template = $template->getRowArray();

        if (isset($template)) {
            if ($template['nama'] == "") {
                $this->session->setFlashdata('pesan_find', 'Dokumen tidak ditemukan!');
                $this->session->setFlashdata('alert-class', 'alert-danger');
                return redirect()->to('/template');
            } else {
                return $this->response->download('templates/' . $template['nama'], null);
            }
        } else {
            return redirect()->to('/template');
        }
    }

    // get nomor automatic
    public function getNomor($str) {
        $indeks_org = $str;
        $indeks_bid = $this->NaskahModel->getIndeksBidang($indeks_org)->getRow();

        $nomor = $this->NaskahModel->getNo($indeks_bid->indeks_bid)->getRow();

        echo ($nomor->nomor);

    }

}
